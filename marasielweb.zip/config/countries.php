<?php
return [
    'language'=>[
        'en'=>'English',
        'ar'=>'عربي',
    ],
    'lang'=>['en','ar','tr'],
    'us'=>['en','USA'],
    'sy'=>['ar','Syria'],
    'bh'=>['ar','Bahrain'],
    'eg'=>['ar','Egypt'],
    'iq'=>['ar','Iraq'],
    'jo'=>['ar','Jordan'],
    'kw'=>['ar','Kuwait'],
    'lb'=>['ar','Lebanon'],
    'om'=>['ar','Oman'],
    'sa'=>['ar','Saudi Arabia'],
    'ae'=>['ar',' the United Arab Emirates'],
    'ye'=>['ar','Yemen'],
    'dz'=>['ar','Algeria'],
    'dj'=>['ar','Djibouti'],
    'ly'=>['ar','Libya'],
    'ma'=>['ar','Morocco'],
    'mr'=>['ar','Mauritania'],
    'so'=>['ar','Somalia'],
    'sd'=>['ar','Sudan'],
    'tn'=>['ar','Tunisia'],

];
