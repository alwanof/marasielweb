<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Drivers\\Providers\\DriversServiceProvider',
    1 => 'Modules\\Drivers\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Drivers\\Providers\\DriversServiceProvider',
    1 => 'Modules\\Drivers\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);