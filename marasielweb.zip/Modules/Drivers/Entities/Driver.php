<?php

namespace Modules\Drivers\Entities;

use Illuminate\Database\Eloquent\Model;

class Driver extends Model
{
    protected $guarded = [];
}
