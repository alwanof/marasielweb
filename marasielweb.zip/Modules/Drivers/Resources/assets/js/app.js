
Vue.component('sheet-component', require('./components/SheetComponent').default);
Vue.component('driversinfo-component', require('./components/DriversinfoComponent').default);
Vue.component('ordersinfo-component', require('./components/OrderinfoComponent').default);
